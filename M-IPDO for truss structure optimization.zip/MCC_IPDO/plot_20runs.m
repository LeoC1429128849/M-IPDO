for i=1:10
semilogy(1:1000,A(i,:))
hold on
end

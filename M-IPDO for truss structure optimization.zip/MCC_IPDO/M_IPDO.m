%在IPDO的基础上增加了MCC框架
%1.改进初始化过程 X_o X_qo X_qr (done)
%2.改变第2和第4个更新公式        ()
%3.增加一个基因库机制 X_gene X_cross limit   ()

function [Best_PD,PDBest_P,PDConv,GCC,GBest]=M_IPDO(N,T,LB,UB,Dim,dDim,F_obj,GCC,GBest)      %N种群数量 T迭代次数
PDBest_P=zeros(1,Dim);           % best positions   %与当前最优所对应的位置
Best_PD=inf;                     %global best fitness全局最优（函数最小值）

X=zeros(N,Dim);                  
X_o =zeros(N,Dim);
X_qo=zeros(N,Dim);
X_qr=zeros(N,Dim);
X_gene=zeros(3,Dim);
X_cross=zeros(3,Dim);
limit=zeros(N,1); %计数器
Xnew=zeros(N,Dim);               %迭代过程中的
PDConv=zeros(1,T);               % Convergance array 记录收敛曲线
BPD_no=zeros(T,1);

%Initialize the positions of solution随机初始位置
%生成X 和 X_o
for i=1:N
    for j=1:Dim
        if j<=dDim %前面的为离散的截面变量
            X(i,j)=round(LB(j)+rand*(UB(j)-LB(j)));%四舍五入取整 截面积取值编号
        else
            X(i,j)=LB(j)+rand*(UB(j)-LB(j));
        end
    end
    X_o(i,:)=LB+UB-X(i,:);
end %初始化完成

M=(LB+UB)/2; %各变量的中间值
% 生成X_qr
for i=1:N
    for j=1:Dim
         if X(i,j)<M(1,j)
            X_qr(i,j)=X(i,j)+rand*(M(1,j)-X(i,j));
        else
            X_qr(i,j)=M(1,j)+rand*(X(i,j)-M(1,j));
         end
         if j<=dDim
             X_qr(i,j)=round(X_qr(i,j));
         end
    end
end
%生成X_qo
for i=1:N
    for j=1:Dim
         if X_o(i,j)>M(1,j)
            X_qo(i,j)=M(1,j)+rand*(X_o(i,j)-M(1,j));
        else
            X_qo(i,j)=X_o(i,j)+rand*(M(1,j)-X_o(i,j));
         end
         if j<=dDim
             X_qo(i,j)=round(X_qo(i,j));
         end
    end
end

OBest=zeros(1,size(X,1));     % old fitness values 个体最优（用于首尾）
CBest=zeros(1,size(X,1));     % new fitness values 本代值（临时容器用于迭代过程中）
geneBest=zeros(3,1);
crossBest=zeros(3,1);
Fval0=zeros(1,size(X,1));
Fval1=zeros(1,size(X,1));
Fval2=zeros(1,size(X,1));
%计算初始位置时的函数值
for i=1:size(X,1)
    Fval0(1,i)=F_obj(X(i,:));
    Fval1(1,i)=F_obj(X_qo(i,:));
    Fval2(1,i)=F_obj(X_qr(i,:));
end
Fval=vertcat(Fval0',Fval1',Fval2');
X_3=cat(1,X,X_qo,X_qr); %构成临时3倍种群
X_3=cat(2,X_3,Fval); %最后一列为该个体对应的目标函数值
X_3=sortrows(X_3,size(X_3,2)); 
X=X_3(1:N,1:end-1);%形成最终的初始种群
X_gene=X(1:3,:);
geneBest=X_3(1:3,end);
%计算初始种群的对应目标函数值
for i=1:size(X,1)
    OBest(1,i)=X_3(i,end);
    if OBest(1,i)<Best_PD %初始化阶段的最优，即第一代迭代的旧全局最优
        Best_PD=OBest(1,i);
        PDBest_P=X(i,:); %与当前最优所对应的位置
    end
end

%参数设置
t=1;                         % starting iteration
delta=0.005;                   % account for individual PD difference   'delta'
% eps(MATLAB自带常数)        %food source quality
epsPD=0.1;                  % food source alarm     'rho'

% 迭代开始 main loop
while t<T+1

    if mod(t,2)==0 %随代数在1和-1间变化
        mu=-1;
    else
        mu=1;
    end

    DS=1.5*(1-t/T)^(2*t/T)*mu;  % Digging strength
    PE=1.5*(1-t/T)^(2*t/T);  % Predator effect
    RL=levym(N,Dim,1.5);     % Levy random number vector
    TPD=repmat(PDBest_P,N,1); %Top PD
    for i=1:N
        for j=1:Dim %该个体寻找下一个目标
            cpd=((TPD(i,j)-rand*X(i,j)))/((TPD(i,j))+eps);
            P=(X(i,j)-mean(X(:,j)))/(TPD(i,j)*(UB(1,j)-LB(1,j))+delta);
            eCB=PDBest_P(1,j)*delta+P;
            % P=delta+(X(i,j)-mean(X(:,j)))/(TPD(i,j)*(UB(1,j)-LB(1,j))+delta);
            if (t<T/4) %阶段1
                Xnew(i,j)=PDBest_P(1,j)-eCB.*epsPD-cpd.*RL(i,j);
            elseif (t<2*T/4 && t>=T/4) %阶段2
                % Xnew(i,j)=PDBest_P(1,j)*X(randi([1 N]),j)*DS*RL(i,j);
                Xnew(i,j)=PDBest_P(1,j)+(X(i,j)-X(randi([1 N]),j))*DS*RL(i,j);
            elseif (t<3*T/4 && t>=2*T/4) %阶段3
                Xnew(i,j)=PDBest_P(1,j)-eCB*eps-cpd*rand;
            else %阶段4
                % Xnew(i,j)=PDBest_P(1,j)*PE*rand;
                Xnew(i,j)=PDBest_P(1,j)-eCB*PE-cpd*rand;
            end
            if j<=dDim %截面积序号变量取整数
                Xnew(i,j)=round(Xnew(i,j));
            end
        end
        %将落在边界外的个体拉回边界
        Xnew(i,Xnew(i,:)>UB)=UB(1,Xnew(i,:)>UB);
        Xnew(i,Xnew(i,:)<LB)=LB(1,Xnew(i,:)<LB);

        CBest(1,i)=F_obj(Xnew(i,:));%CBest存储这一轮
        if CBest(1,i)<OBest(1,i)%判断个体是否需要更新位置,更新最优
            X(i,:)=Xnew(i,:);
            OBest(1,i)=CBest(1,i);
            limit(i)=0; %清零
        else %没有找到更好位置
            if t>=T/2 %在迭代的后半程
            limit(i)=limit(i)+1;  %计数器加1
            end
        end
        if OBest(1,i)<Best_PD%更新这一轮之内的最优
            Best_PD=OBest(1,i);
            PDBest_P=X(i,:);
        end
    end %end of for i

    %基因库更新过程
    [~,mindex1]=mink(OBest,3); % 取种群中适应度前3的个体
    for i =1:3 %交叉变异生成X_cross
        q=rand;
        for j=1:Dim 
            X_cross(i,j)=q*X(mindex1(i),j)+(1-q)*X_gene(i,j);
            if j<=dDim
                X_cross(i,j)=round(X_cross(i,j));
            end
        end
        X_cross(i,X_cross(i,:)>UB)=UB(1,X_cross(i,:)>UB);
        X_cross(i,X_cross(i,:)<LB)=LB(1,X_cross(i,:)<LB);
        crossBest(i,1)=F_obj(X_cross(i,:));
    end
    Temp1=cat(1,X(mindex1,:),X_gene,X_cross); %和子代一共9只个体
    Temp2=cat(1,OBest(mindex1)',geneBest,crossBest);
    [geneBest,mindex2]=mink(Temp2,3); %取适应度前三的个体存入基因库
    X_gene=Temp1(mindex2,:);
    
    if t>1/2*T %算法进入后期  开始检查计数器 limit
        for i=1:N
            if limit(i)>=0.15*T
                d=randi([1,3]);
                X(i,:)=X_gene(d,:);
                OBest(i)=geneBest(d);
                limit(i)=0;
            end
        end
    end
  
    %GCC 更新
    if Best_PD<GCC(t)
        GCC(t)=Best_PD;
         if mod(t,150)==0 && t<=500 
             GBest(t/150,:)=PDBest_P;
         end
    end
        
    if GCC(t)<=Best_PD
        if mod(t,150)==0 && t<=500
            Best_PD=GCC(t);
            PDBest_P=GBest(t/150,:);
        end
    end
    
    PDConv(t)=Best_PD;  %Update the convergence curve记下这一代的全局最优记录收敛情况
    if mod(t,50)==0  %每五十代输出一次目前的最优
        display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(Best_PD)]);
    end

    t=t+1;
end %end for loop
end%end for function
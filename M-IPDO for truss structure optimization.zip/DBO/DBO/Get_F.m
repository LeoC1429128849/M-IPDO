
%边界条件的设立
function [LB,UB,Dim,dDim,F_obj] = Get_F(F)
switch F
    case'F15'
        F_obj = @Truss_analyzing15bars_shape;
        LB=[1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 100 220 100 100 50 -20 -20 20];
        UB=[32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,140,260,140,140,90,20,20,60];
        Dim=23;
        dDim=15;

    case'F18'
        F_obj = @Truss_analyzing18bars_shape;
        LB=[ 1  1  1  1  775 -225 525 -225 275 -225  25 -225];
        UB=[80 80 80 80 1225  245 975  245 725  245 475  245];
        Dim=12;
        dDim=8;
    case'F25'
        F_obj = @Truss_analyzing25bars_shape;
        LB=[ones(1,8)*1 20 40 90 40 100];
        UB=[ones(1,8)*30 60 80 130 80 140];
        Dim=13;
        dDim=8;
    
end %end for case
end %end for fuction


%F15 15杆桁架体系
function  [TrussWeight,stress,violation]=Truss_analyzing15bars_shape(X)
%This solution illustrate the analyzing of truss structure
%Input

SECTION_List1= [0.111, 0.141, 0.174, 0.220, 0.270, 0.287, 0.347, 0.440, 0.539, 0.954, 1.081, 1.174, 1.333, 1.488, 1.764, 2.142, 2.697, 2.800, 3.131, 3.565, 3.813, 4.805, 5.952, 6.572, 7.192, 8.525, 9.300, 10.850, 13.330, 14.290, 17.170, 19.180]; % discrete section list    32 choices
A=[SECTION_List1(X(1)), SECTION_List1(X(2)), SECTION_List1(X(3)), SECTION_List1(X(4)), SECTION_List1(X(5)), SECTION_List1(X(6)), SECTION_List1(X(7)), SECTION_List1(X(8)), SECTION_List1(X(9)), SECTION_List1(X(10)), SECTION_List1(X(11)), SECTION_List1(X(12)), SECTION_List1(X(13)), SECTION_List1(X(14)), SECTION_List1(X(15))];
A=A';%转化为列向量 行号代表杆件编号


Sall=25;    %allowable stress 容许应力
E=10000;    %Modulus of elasticity 弹性模量 /*可以改变为矩阵形式*/
D=0.1;      % holds material density 密度

N=[1 0 120;             % 节点号 x坐标 y坐标
    2 X(16) X(18);
    3 X(17) X(19);
    4 360 X(20);
    5 0 0;
    6 X(16) X(21);
    7 X(17) X(22);
    8 360 X(23)];

M=[1 1 2 E A(1);       %杆件编号 start节点 end节点 弹模E 截面积A
    2 2 3 E A(2);
    3 3 4 E A(3);
    4 5 6 E A(4);
    5 6 7 E A(5);
    6 7 8 E A(6);
    7 2 6 E A(7);
    8 3 7 E A(8);
    9 4 8 E A(9);
    10 1 6 E A(10);
    11 2 5 E A(11);
    12 2 7 E A(12);
    13 3 6 E A(13);
    14 3 8 E A(14);
    15 4 7 E A(15)]; 
nn =size(N,1); %节点数 num of nodes
ndof = 2*nn; %自由度数 num of degree of freedom
ne = size(M,1);%杆件数量 elements
K = zeros(ndof,ndof);% 刚度矩阵
U = zeros(ndof,1);% 节点位移列表
f = zeros(ndof,1); %外力荷载
F = zeros(ne,1); %杆件轴力
W = zeros(ne,1); %杆件质量
L = zeros(ne,1); %杆件长度
stress = zeros(ne,1);%应力
strain = zeros(ne,1);%应变

f(16)=-10; %外荷载大小

fnod=[3 4 5 6 7 8 11 12 13 14 15 16];     %unconstrained dofs 不受约束的自由度（存在位移）
for e=1:ne         %loops over all the element
    n1=M(e,2);     %starting node of element
    n2=M(e,3);     %end node of element
    x1=N(n1,2);  y1=N(n1,3);  %x and y coordinates for 1st node
    x2=N(n2,2);  y2=N(n2,3);  %x and y coordinates for 2nd node
    L(e)=sqrt((x2-x1)^2+(y2-y1)^2);    %element length
    C=(x2-x1)/L(e);
    S=(y2-y1)/L(e);
    C2=C*C;
    S2=S*S;
    CS=C*S;
    E= M(e,4); %Holds modolus of elasticiy of element
    A(e)= M(e,5);

    ke=((A(e)*E)/(L(e))*[C2 CS -C2 -CS;   %单元刚度矩阵
                        CS S2 -CS -S2;
                        -C2 -CS C2 CS;
                        -CS -S2 CS S2]);

    s1=[M(e,2)*2-1 M(e,2)*2];
    s2=[M(e,3)*2-1 M(e,3)*2];  %location where ke is to scatter in the global stiffness matrix
    K([s1,s2],[s1,s2])= K([s1,s2],[s1,s2])+ke;    %adding ke to k
end
% solving for the nodal displacement,U 节点位移
U(fnod)= K(fnod,fnod)\f(fnod);
% solving strain, stress and force for each element
for e=1:ne
    n1=M(e,2);
    n2=M(e,3);
    x1=N(n1,2);  y1=N(n1,3);
    x2=N(n2,2);  y2=N(n2,3);
    s1=[M(e,2)*2-1 M(e,2)*2];
    s2=[M(e,3)*2-1 M(e,3)*2];
    L(e)=sqrt((x2-x1)^2+(y2-y1)^2);
    C=(x2-x1)/L(e); %cos
    S=(y2-y1)/L(e); %sin
    d=[C S 0 0;0 0 C S]*U([s1,s2]);  %displacement of one node
    strain(e)=(d(2)-d(1))/L(e);   %compute strain for each element, strain=(d2-d1)/L
    stress(e)=E*strain(e);   %compute stresse for each element, stress=strain*modulus of elesticity for each element应力
    A(e)=M(e,5);
    F(e)=A(e)*stress(e);   %compute axial force for each element, force=stress*cross section area for each element杆轴力
    W(e)=D*A(e)*L(e);

end

net_weight=sum(W); %结构总重量
penalty_constant=1;
Svio=zeros(1,ne);
c1=size(Svio);

for e=1:ne
    Svio(e)=(abs((stress(e))/Sall))-1;
    if Svio(e)<=0
        c1(e)=0;
    else 
        c1(e)=Svio(e);
    end
end

Sviolation=sum(c1);
violation=Sviolation;
TrussWeight=net_weight*(1+penalty_constant*violation); %Cost function with penalty
end


%F18 18杆桁架体系
function [TrussWeight,stress,violation]=Truss_analyzing18bars_shape(X)

SECTION_List1= 2:0.25:21.75; % discrete section list    80 choices
A=[SECTION_List1(X(1)), SECTION_List1(X(2)), SECTION_List1(X(3)), SECTION_List1(X(4))]; %X(1:4) 是截面变量
A=A';%转化为列向量 行号代表杆件编号

Sall=20;%ksi    %allowable stress 容许应力 最大拉压
E=10000;%ksi    %Modulus of elasticity 弹性模量 /*可以改变为矩阵形式*/
D=0.1;%lb/in^3          % holds material density 密度

N=[1 1250 250;             % 节点号 x坐标 y坐标 11个节点
    2 1000 250;
    3 X(5) X(6);
    4 750 250;
    5 X(7) X(8);
    6 500 250;
    7 X(9) X(10);
    8 250 250;
    9 X(11) X(12);
    10 0 250;
    11 0 0];

M=[1 1 2 E A(1);       %杆件编号 start节点 end节点 弹模E 截面积A 18根杆件
    2 1 3 E A(2);
    3 2 3 E A(3);
    4 2 4 E A(1);
    5 3 4 E A(4);
    6 3 5 E A(2);
    7 4 5 E A(3);
    8 4 6 E A(1);
    9 5 6 E A(4);
    10 5 7 E A(2);
    11 6 7 E A(3);
    12 6 8 E A(1);
    13 7 8 E A(4);
    14 7 9 E A(2);
    15 8 9 E A(3);
    16 8 10 E A(1);
    17 9 10 E A(4);
    18 9 11 E A(2)]; 

nn =size(N,1); %节点数 num of nodes
ndof = 2*nn; %自由度数 num of degree of freedom
ne = size(M,1); %杆件数量 elements

K = zeros(ndof,ndof); %刚度矩阵
U = zeros(ndof,1); %节点位移列表
f = zeros(ndof,1); %外力荷载
F = zeros(ne,1); %杆件轴力
W = zeros(ne,1); %杆件质量
L = zeros(ne,1); %杆件长度
stress = zeros(ne,1); %应力
strain = zeros(ne,1); %应变
Bulk = zeros(ne,1);   %每根杆件的屈曲强度 */只对受压杆架起约束作用
%外荷载大小
f(16)=-20; 
f(12)=-20;
f(8)=-20; 
f(4)=-20; 
f(2)=-20; 

fnod=[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18];     %unconstrained dofs 不受约束的自由度（存在位移）

for e=1:ne         %循环所有杆件
    n1=M(e,2);     %starting node of element起点
    n2=M(e,3);     %end node of element终点
    x1=N(n1,2);  y1=N(n1,3);  %起点坐标
    x2=N(n2,2);  y2=N(n2,3);  %终点坐标
    L(e)=sqrt((x2-x1)^2+(y2-y1)^2);    %杆件长度
    C=(x2-x1)/L(e); %cos
    S=(y2-y1)/L(e); %sin
    C2=C*C;
    S2=S*S;
    CS=C*S;
    E= M(e,4);  %Holds modolus of elasticiy of element
    A(e)= M(e,5);
    Bulk(e)=4*E*A(e)./L(e)^2;  %屈曲强度 buckling_strength = 4EA/L
    ke=((A(e)*E)/(L(e))*[C2 CS -C2 -CS;   %单元刚度矩阵
                        CS S2 -CS -S2;
                        -C2 -CS C2 CS;
                        -CS -S2 CS S2]);
    s1=[M(e,2)*2-1 M(e,2)*2];
    s2=[M(e,3)*2-1 M(e,3)*2];  %location where ke is to scatter in the global stiffness matrix
    K([s1,s2],[s1,s2])= K([s1,s2],[s1,s2])+ke;    %拼装刚度矩阵
end
% solving for the nodal displacement,U 节点位移
U(fnod)= K(fnod,fnod)\f(fnod);
% solving strain, stress and force for each element
for e=1:ne
    n1=M(e,2);
    n2=M(e,3);
    x1=N(n1,2);  y1=N(n1,3);
    x2=N(n2,2);  y2=N(n2,3);
    s1=[M(e,2)*2-1 M(e,2)*2];
    s2=[M(e,3)*2-1 M(e,3)*2];
    L(e)=sqrt((x2-x1)^2+(y2-y1)^2);
    C=(x2-x1)/L(e); %cos
    S=(y2-y1)/L(e); %sin
    d=[C S 0 0;0 0 C S]*U([s1,s2]);  %displacement of one node 节点的位移
    strain(e)=(d(2)-d(1))/L(e);   %compute strain for each element, strain=(d2-d1)/L
    stress(e)=E*strain(e);   %compute stresse for each element, stress=strain*E 应力
    A(e)=M(e,5);
    F(e)=A(e)*stress(e);   %compute axial force for each element, force=stress*A 杆轴力
    W(e)=D*A(e)*L(e);
end

net_weight=sum(W); %结构总重量
penalty_constant=1;
Svio=zeros(1,ne); %
c1=size(Svio);
c2=zeros(1,ne);
for e=1:ne
    Svio(e)=abs((stress(e))/Sall)-1;
    if Svio(e)<=0
        c1(e)=0;
    else 
        c1(e)=Svio(e);
    end
end
for e=1:ne
    if stress(e)<0 %受压杆件 
       Svio(e)=abs(stress(e)/Bulk(e))-1;
    end
    if Svio(e)<=0
        c2(e)=0;
    else 
        c2(e)=Svio(e);
    end
end

Sviolation=sum(c1)+sum(c2); %应力 违反度
violation=Sviolation; %总违反度 
TrussWeight=net_weight*(1+penalty_constant*violation)^2; %Cost function with penalty
end

%F25 25杆桁架体系
function [TrussWeight,stress,violation,U]=Truss_analyzing25bars_shape(X)
%节点坐标
Coord=[-37.5     0 200;%1
        37.5     0 200;%2
       -X(9)  X(10) X(11);%3
        X(9)  X(10) X(11);%4
        X(9) -X(10) X(11);%5
       -X(9) -X(10) X(11);%6
        -X(12)   X(13)   0;%7
         X(12)   X(13)   0;%8
         X(12)  -X(13)  0;%9
        -X(12) -X(13)   0];%10
%定义杆件节点
Con=[1 2;1 4;2 3;1 5;2 6;2 4;2 5;1 3;1 6;3 6;4 5;3 4;5 6;3 10;6 7;4 9;5 8;4 7;3 8;5 10;6 9;6 10;3 7;4 8;5 9];
% 自由度 (free=0 &  fixed=1); for 2-D trusses the last column is equal to 1
Re=zeros(size(Coord));
Re(7:10,:)=[1 1 1;1 1 1;1 1 1;1 1 1];
%节点荷载
Load=zeros(size(Coord));
Load([1:3,6],:)=[1 -10 -10;0 -10 -10;0.5 0 0;0.6 0 0];%kips
%弹性模量
E=ones(1,size(Con,1))*1e4;%1000ksi
%待选截面   30choices
AV=[0.1*(1:26),2.8,3,3.2,3.4];%in^2
%杆件截面分组
Group={{1;[2;3;4;5];[6;7;8;9];[10;11];[12;13];[14;15;16;17];[18;19;20;21];[22;23;24;25]}};
%杆件截面
A=zeros(1,size(Con,1));
%容许应力
TM=40;%ksi
%允许节点位移
DM=0.35; %in
%杆件材料密度
RO=.1;%lb/in^3
D=struct('Coord',Coord','Con',Con','Re',Re','Load',Load','E',E','A',A','AV',AV','TM',TM','DM',DM','RO',RO','Group',Group);
%将截面积分配给每个截面组
for j=1:size(D.Group,1)
    D.A([D.Group{j}])=D.AV(X(j));
end

w=size(D.Re);
K=zeros(3*w(2)); %总纲矩阵
U=1-D.Re;
f=find(U);%没有被约束的自由度

WE=0;%没有惩罚的桁架 质量
Tj=zeros(3,1);
for i=1:size(D.Con,2)
    H=D.Con(:,i);
    C=D.Coord(:,H(2))-D.Coord(:,H(1));
    Le=norm(C);
    T=C/Le;
    k=T*T'; %单元刚度矩阵
    G=D.E(i)*D.A(i)/Le;
    Tj(:,i)=G*T;
    e=[3*H(1)-2:3*H(1),3*H(2)-2:3*H(2)];
    K(e,e)=K(e,e)+G*[k -k;-k k];
    WE=WE+Le*D.A(i)*D.RO;
end
U(f)=K(f,f)\D.Load(f);
F=sum(Tj.*(U(:,D.Con(2,:))-U(:,D.Con(1,:))));
stress=F'./D.A;



%约束违反度计算
TS=(((abs(F'))./D.A)/D.TM)-1;%Tension
US=abs(U')/D.DM-1;%Displacement
PS=sum(TS.*(TS>0));
PD=sum(sum(US.*(US>0)));
violation=PS+PD;
TrussWeight=WE*(1+violation);% Penalty function
end
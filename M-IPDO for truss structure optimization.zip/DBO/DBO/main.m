% -----------------------------------------------------------------------------------------------------------
% Dung Beetle Optimizer: (DBO) (demo)
% Programmed by Jian-kai Xue    
% Updated 28 Nov. 2022.                     
%
% This is a simple demo version only implemented the basic         
% idea of the DBO for solving the unconstrained problem.    
% The details about DBO are illustratred in the following paper.    
% (To cite this article):                                                
%  Jiankai Xue & Bo Shen (2022) Dung beetle optimizer: a new meta-heuristic
% algorithm for global optimization. The Journal of Supercomputing, DOI:
% 10.1007/s11227-022-04959-6
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear 
clc

SearchAgents_no=30; % Number of search agents
F_name='F15'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper)
Max_iter=1000; % Maximum numbef of iterations
runNum=20;
% Load details of the selected benchmark function
[lb,ub,Dim,dDim,fobj]=Get_F(F_name);
A=zeros(runNum,Max_iter);
DBBest_PerRun=zeros(runNum,Dim);%记录每一run的最佳设计方案
for run=1:runNum
    disp(['run #' num2str(run)]);
    [fMin,bestX,DBO_curve]=DBO(SearchAgents_no,Max_iter,lb,ub,Dim,dDim,fobj); % Call PDO调用 前面的是返还的值
    A(run,:)=DBO_curve;
    DBBest_PerRun(run,:)=bestX;
    display(['The best-obtained solution by DBO is : ', num2str(PDBest_P)]);  %最优设计函数变量
    display(['The best optimal value of the objective funciton found by PDO is : ', num2str(Best_PD)]);  %最优目标函数值
end


semilogy(DBO_curve,'Color','g')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
%axis tight
grid on
box on
legend('DBO')
display(['The best solution obtained by DBO is : ', num2str(bestX)]);
display(['The best optimal value of the objective funciton found by DBO is : ', num2str(fMin)]);





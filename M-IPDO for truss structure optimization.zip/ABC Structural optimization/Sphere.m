function ObjVal=Sphere(Colony,xd)
S=Colony.*Colony;
ObjVal=sum(S');

function  TrussWeight=Truss_analyzing15bars_shape(X)
%This solution illustrate the analyzing of truss structure
%Input

SECTION_List1= [0.111, 0.141, 0.174, 0.220, 0.270, 0.287, 0.347, 0.440, 0.539, 0.954, 1.081, 1.174, 1.333, 1.488, 1.764, 2.142, 2.697, 2.800, 3.131, 3.565, 3.813, 4.805, 5.952, 6.572, 7.192, 8.525, 9.300, 10.850, 13.330, 14.290, 17.170, 19.180]; % discrete section list    32 choices
A=[SECTION_List1(X(1)), SECTION_List1(X(2)), SECTION_List1(X(3)), SECTION_List1(X(4)), SECTION_List1(X(5)), SECTION_List1(X(6)), SECTION_List1(X(7)), SECTION_List1(X(8)), SECTION_List1(X(9)), SECTION_List1(X(10)), SECTION_List1(X(11)), SECTION_List1(X(12)), SECTION_List1(X(13)), SECTION_List1(X(14)), SECTION_List1(X(15))];
A=A';%转化为列向量 行号代表杆件编号     
% SECTION_List2=100:0.001:140;
% SECTION_List3=220:0.001:260;
% SECTION_List4=50:0.001:90;
% SECTION_List5=-20:0.001:20;
% SECTION_List6=20:0.001:60;

Sall=25;    %allowable stress 容许应力
E=10000;    %Modulus of elasticity 弹性模量 /*可以改变为矩阵形式*/
D=0.1;      % holds material density 密度

N=[1 0 120;
   2 X(16) X(18);
   3 X(17) X(19);
   4 360 X(20);
   5 0 0;
   6 X(16) X(21);
   7 X(17) X(22);
   8 360 X(23)];% 节点的坐标 x and y coordinates
M=[1 1 2 E A(1);
   2 2 3 E A(2);
   3 3 4 E A(3);
   4 5 6 E A(4);
   5 6 7 E A(5);
   6 7 8 E A(6);
   7 2 6 E A(7);
   8 3 7 E A(8);
   9 4 8 E A(9);
   10 1 6 E A(10);
   11 2 5 E A(11);
   12 2 7 E A(12);
   13 3 6 E A(13);
   14 3 8 E A(14);
   15 4 7 E A(15)]; %杆件编号 start节点 end节点 弹模E 截面积A
nn =size(N,1); %节点数 num of nodes
ndof = 2*nn; %自由度数 num of degree of freedom
ne = size(M,1);%杆件数量 elements
K = zeros(ndof,ndof);% 刚度矩阵
U = zeros(ndof,1);% 节点位移列表
f = zeros(ndof,1); %外力荷载
F = zeros(ne,1); %杆件轴力
stress = zeros(ne,1);%应力
strain = zeros(ne,1);%应变

f(16)=-10;

fnod=[3 4 5 6 7 8 11 12 13 14 15 16];     %unconstrained dofs 不受约束的自由度（存在位移）
for e=1:ne         %loops over all the element
    n1=M(e,2);     %starting node of element
    n2=M(e,3);     %end node of element
    x1=N(n1,2);  y1=N(n1,3);  %x and y coordinates for 1st node
    x2=N(n2,2);  y2=N(n2,3);  %x and y coordinates for 2nd node
    L(e)=sqrt((x2-x1)^2+(y2-y1)^2);    %element length
    C=(x2-x1)/L(e);
    S=(y2-y1)/L(e);
    C2=C*C;
    S2=S*S;
    CS=C*S;
    E= M(e,4); %Holds modolus of elasticiy of element
    A(e)= M(e,5);
    ke=((A(e)*E)/(L(e))*[C2 CS -C2 -CS;   %stiffness matrix for element
                         CS S2 -CS -S2;
                        -C2 -CS C2 CS;
                        -CS -S2 CS S2]);
    s1=[M(e,2)*2-1 M(e,2)*2];
    s2=[M(e,3)*2-1 M(e,3)*2];  %location where ke is to scatter in the global stiffness matrix
    K([s1,s2],[s1,s2])= K([s1,s2],[s1,s2])+ke;    %adding ke to k
end
% solving for the nodal displacement,U 节点位移
U(fnod)= K(fnod,fnod)\f(fnod);
% solving strain, stress and force for each element
for e=1:ne      
    n1=M(e,2);     
    n2=M(e,3);     
    x1=N(n1,2);  y1=N(n1,3);  
    x2=N(n2,2);  y2=N(n2,3);
    s1=[M(e,2)*2-1 M(e,2)*2];
    s2=[M(e,3)*2-1 M(e,3)*2];
    L(e)=sqrt((x2-x1)^2+(y2-y1)^2);    
    C=(x2-x1)/L(e); %cos
    S=(y2-y1)/L(e); %sin
    d=[C S 0 0;0 0 C S]*U([s1,s2]);  %displacement of one node
    strain(e)=(d(2)-d(1))/L(e);   %compute strain for each element, strain=(d2-d1)/L
    stress(e)=E*strain(e);   %compute stresse for each element, stress=strain*modulus of elesticity for each element应力
    A(e)=M(e,5);
    F(e)=A(e)*stress(e);   %compute axial force for each element, force=stress*cross section area for each element杆轴力
    W(e)=D*A(e)*L(e);
%     BL(e)=(algha*E*A(e))/(L(e))^2;
%     BS(e)=(10.1*3.14*E*A(e))/(8*(L(e))^2);
end
net_weight=sum(W);

        penalty_constant=1;
        Svio=zeros(1,ne);
        c1=size(Svio); 
          
for e=1:ne
        Svio(e)=(abs((stress(e))/Sall))-1;
        if Svio(e)<=0
          c1(e)=0;
        else c1(e)=Svio(e);
            
        end
end

    Sviolation=sum(c1);


        violation=Sviolation;
        TrussWeight=net_weight*(1+penalty_constant*violation); %Cost function with penalty
        
       
end

function BestLoc = FindBestLoc(population, center, Radius)
total=0;
for i=1:size(population)
distance[i]=sqrt(population(center)-population(i));
total=total+distance[i];
end
mean =total/(size(distance)-1);
count=0;
for i=1:size(population)
if (distance[i] < Radius*mean)
    count=count+1;
end
end
s=0;
for i=1:size(population)
    if (distance[i] < Radius*mean)
      neighbor[s]=population[i];
      s=s+1;
    end
end
end
    

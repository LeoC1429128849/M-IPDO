 tic
 clear all
 close all 
 clc
% This code for shape optimization of 2D 15bar truss structure 
%/* Control Parameters of ABC algorithm*/
NP=100; %/* The number of colony size (employed bees+onlooker bees)*/
FoodNumber=NP/2; %/*The number of food sources equals the half of the colony size*/
%/* Problem specific variables*/
objfun=@Truss_analyzing15bars_shape; %cost function to be optimized 目标函数 
D=23; %/*The number of parameters of the problem to be optimized*/
DSize=15;%截面积
DShape=8;%节点坐标
maxCycle=300; %/*The number of cycles for foraging {a stopping criteria}*/最大迭代次数
limit=maxCycle/3; %/*A food source which could not be improved through "limit" trials is abandoned by its employed bee*/放弃条件
ub=[32,32,32,32,32,32,32,32,32,32,32,32,32,32,32,140,260,140,140,90,20,20,60]; %/*lower bounds of the parameters. */
lb=[1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 100 220 100 100 50 -20 -20 20];%/*upper bound of the parameters.*/

runtime=3;%/*Algorithm can be run many times in order to see its robustness*/

GlobalMins=zeros(1,runtime);
GlobalMaxs=zeros(1,runtime);

for run=1:runtime
  
% /*All food sources are initialized */
%/*Variables are initialized in the range [lb,ub]. If each parameter has different range, use arrays lb[j], ub[j] instead of lb and ub */

%初始化
    for i=1:FoodNumber        
        for j=1:D
            if j<=DSize%前15个变量为截面积
            Foods(i,j)=round(lb(j)+rand()*(ub(j)-lb(j)));%四舍五入取整 截面积取值编号
            else
            Foods(i,j)=lb(j)+rand()*(ub(j)-lb(j));    
            end
        end
    end
    for i=1:FoodNumber
   ObjVal(i,1)=feval(objfun,Foods(i,:));
    end

Fitness=calculateFitness(ObjVal);%一个列矩阵

%reset trial counters
trial=zeros(1,FoodNumber);%记录一个食物源被优化了多少次，如果达到limit则放弃该处

%/*The best food source is memorized*/
BestInd=find(ObjVal==min(ObjVal));%最优索引
BestInd=BestInd(end);%取最后一个
GlobalMin=ObjVal(BestInd);%全局最小值
GlobalParams=Foods(BestInd,:);%全局最小处的参数值
% The worst food source is memorized
WorstInd=find(ObjVal==max(ObjVal));
WorstInd=WorstInd(end);
GlobalMax=ObjVal(WorstInd);
GlobalParams2=Foods(WorstInd,:);

iter=1;
while iter<=maxCycle

%%%%%%%%% EMPLOYED BEE PHASE %%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:(FoodNumber)%遍历所有食物源
        
        %/*The parameter to be changed is determined randomly*/
        Param2Change=fix(rand*DShape)+1+DSize;%随机选择一个shape变量
        Param3Change=fix(rand*DSize)+1;%随机选择一个size变量
        %/*A randomly chosen solution is used in producing a mutant solution of the solution i*/
        neighbour=fix(rand*(FoodNumber))+1;
       
        %/*Randomly selected solution must be different from the solution i*/        
            while(neighbour==i)
                neighbour=fix(rand*(FoodNumber))+1;
            end
        
       sol=Foods(i,:);% sol 是下一个目标食物源（1行 D列）
       %  /*v_{ij}=x_{ij}+\phi_{ij}*(x_{kj}-x_{ij}) */
       sol(Param2Change)=Foods(i,Param2Change)+(Foods(i,Param2Change)-Foods(neighbour,Param2Change))*(rand-0.5)*2;
       sol(Param3Change)=Foods(i,Param3Change)+(Foods(i,Param3Change)-Foods(neighbour,Param3Change))*(rand-0.5)*2;
       for j=1:D
          if j<=DSize
             sol(j)=round(sol(j));
          end   
       end
       %  /*if generated parameter value is out of boundaries, it is shifted onto the boundaries*/
        sol(1,sol(1,:)<lb)=lb(1,sol(1,:)<lb);
        sol(1,sol(1,:)>ub)=ub(1,sol(1,:)>ub);
        
        %evaluate new solution
        ObjValSol= objfun(sol);%算出新目标的结果
        FitnessSol=calculateFitness(ObjValSol);
        
       % /*a greedy selection is applied between the current solution i and its mutant*/  
       if (FitnessSol>Fitness(i)) %/*If the mutant solution is better than the current solution i, replace the solution with the mutant and reset the trial counter of solution i*/
            Foods(i,:)=sol;
            Fitness(i)=FitnessSol;
            ObjVal(i)=ObjValSol;
            trial(i)=0;
        else
            trial(i)=trial(i)+1; %/*if the solution i can not be improved, increase its trial counter*/
       end
        
    end

%%%%%%%%%%%%%%%%%%%%%%%% CalculateProbabilities %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%/* A food source is chosen with the probability which is proportioal to its quality*/
%/*Different schemes can be used to calculate the probability values*/
%/*For example prob(i)=fitness(i)/sum(fitness)*/
%/*or in a way used in the method below prob(i)=a*fitness(i)/max(fitness)+b*/
%/*probability values are calculated by using fitness values and normalized by dividing maximum fitness value*/

prob=(0.9.*Fitness./max(Fitness))+0.1;%归一化 各食物源处所得解与最优解的比值
  
%%%%%%%%%%%%%%%%%%%%%%%% ONLOOKER BEE PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

i=1;
t=0;
while(t<FoodNumber)
    if(rand<prob(i))%概率越大的食物源，越有可能旁观者选择，再一次优化优化过程与雇佣者完全一样（随机选择两个变量进行突变）
        t=t+1;
        %/*The parameter to be changed is determined randomly*/
        Param2Change=fix(rand*DShape)+1+DSize;
        Param3Change=fix(rand*DSize)+1;        
        %/*A randomly chosen solution is used in producing a mutant solution of the solution i*/
        neighbour=fix(rand*(FoodNumber))+1;
       
        %/*Randomly selected solution must be different from the solution i*/        
            while(neighbour==i)
                neighbour=fix(rand*(FoodNumber))+1;
            end
        
       sol=Foods(i,:);
       %  /*v_{ij}=x_{ij}+\phi_{ij}*(x_{kj}-x_{ij}) */
       sol(Param2Change)=Foods(i,Param2Change)+(Foods(i,Param2Change)-Foods(neighbour,Param2Change))*(rand-0.5)*2;
       sol(Param3Change)=Foods(i,Param3Change)+(Foods(i,Param3Change)-Foods(neighbour,Param3Change))*(rand-0.5)*2;
               for j=1:D
          if j<=DSize
             sol(j)=round(sol(j));
          end   
               end 
       %  /*if generated parameter value is out of boundaries, it is shifted onto the boundaries*/
        sol(1,sol(1,:)<lb)=lb(1,sol(1,:)<lb);
        sol(1,sol(1,:)>ub)=ub(1,sol(1,:)>ub);
        
        %evaluate new solution
        ObjValSol=feval(objfun,sol);
        FitnessSol=calculateFitness(ObjValSol);
        
       % /*a greedy selection is applied between the current solution i and its mutant*/
       if (FitnessSol>Fitness(i)) %/*If the mutant solution is better than the current solution i, replace the solution with the mutant and reset the trial counter of solution i*/
            Foods(i,:)=sol;
            Fitness(i)=FitnessSol;
            ObjVal(i)=ObjValSol;
            trial(i)=0;
        else
            trial(i)=trial(i)+1; %/*if the solution i can not be improved, increase its trial counter*/
       end
    end
    
    i=i+1;
    if (i==(FoodNumber)+1) 
        i=1;
    end   
end 
       
        

%/*The best food source is memorized*/
         ind=find(ObjVal==min(ObjVal));
         ind=ind(end);
         if (ObjVal(ind)<GlobalMin)
         GlobalMin=ObjVal(ind);
         GlobalParams=Foods(ind,:);
         end
         
        ffmin(iter,run)=GlobalMin;    % storing best fitness
        ffite(run)=iter;         % storing iteration count       
         
%%%%%%%%%%%% SCOUT BEE PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%/*determine the food sources whose trial counter exceeds the "limit" value. 
%In Basic ABC, only one scout is allowed to occur in each cycle*/

ind=find(trial==max(trial));
ind=ind(end);

%放弃没有开发价值的食物源并寻找新的代替
if (trial(ind)>limit)
    trial(ind)=0;
for j=1:D
    if j<=DSize
    sol(j)=round(rand()+lb(j).*(ub(j)-lb(j)));
xmin=0.9;
xmax=1.1;
% x=xmin+rand(1,1)*(xmax-xmin);
% sol(j)=round((xmin+rand(1,1)*(xmax-xmin))*GlobalParams(j));
    else
    sol(j)=rand()+lb(j).*(ub(j)-lb(j));
% sol(j)=(xmin+rand(1,1)*(xmax-xmin))*GlobalParams(j);
    end
end
ObjValSol=feval(objfun,sol);
    FitnessSol=calculateFitness(ObjValSol);
    Foods(ind,:)=sol;
    FitnessSol(ind)=FitnessSol;
    ObjVal(ind)=ObjValSol;
%     [summeanofit]=sum(ffmin');
end

 % displaying iterative results
        if iter==1
            disp(sprintf('Iteration    Best particle    Objective fun'));
        end
        disp(sprintf('%8g  %8g          %8.4f',iter,ind,GlobalMin));
        iter=iter+1;

end % End of ABC

GlobalMins(run)=GlobalMin;
GlobalMaxs(run)=GlobalMax;

Mean=mean(GlobalMins);
Stds1=std(GlobalMins);%标准差
BestValue=min(GlobalMins);
WorstValue=max(GlobalMins);

    [worstofit]=max(ffmin');
for k1 = 1:size(ffmin)                                        % Tell 慺or� To Iterate Over The Columns (Dimension 2)
    summeanofit(k1) = sum(ffmin(k1,:));                             % Sum Column 慿1� And Store In 慉colsum(k1)�
end
    meanofit=summeanofit./runtime;
    CC=NP*maxCycle;
fvalue=Truss_analyzing15bars_shape(GlobalParams);
    fff(run)=fvalue;
    rpbest(run,:)=GlobalParams;
    disp(newline);
    fprintf('*********************************************************\n');
    fprintf('Final Results-----------------------------\n');
    [bestfun,bestrun]=min(fff)
    best_variables=rpbest(bestrun,:)
    fprintf('*********************************************************\n');
%     toc
    
end %end of runs
% save all
plot(ffmin(1:ffite(bestrun),bestrun), 'LineWidth', 1.5);
hold on
plot(1:ffite,worstofit, 'LineWidth', 1.5);
plot(1:ffite,meanofit, 'LineWidth', 1.5);
    xlabel('Iteration');
    ylabel('Weight');
    title('ABC convergence characteristic'); 
    legend('best','worst','mean');
% hold on



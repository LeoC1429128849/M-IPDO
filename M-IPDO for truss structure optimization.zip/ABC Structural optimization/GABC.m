%**************************************************************************************************

%**************************************************************************************************

clc;
clear all;
tic;
format long;
format compact;
'GABC'

tic

problemSet = [1:22];
for problemIndex = 1 : length(problemSet)

    problem = problemSet(problemIndex);

    % Define the dimension of the problem 
    if problem ==21|problem==22
        n=100;
    else
        n =30;
    end
    D=n;
    Lmax=200;                                   
    MCN=10000;
    MaxFE=2*5*10.^(4); 
    if problem ==6 
        Vot=40
    elseif problem ==9 
        Vot=10.^(-1)
    elseif problem ==10 
        Vot=5        
    elseif problem ==21 
        Vot=-78         
    elseif problem ==22 
        Vot=-95
    else
        Vot=10.^(-8)
    end
        
    switch problem
                         
        case 1

            lu=[-100*ones(1,n);100*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];
                          
        case 2

            lu=[-100*ones(1,n);100*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];
                       
        case 3

            lu=[-10*ones(1,n);10*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];       
                
        case 4

            lu=[-1*ones(1,n);1*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];   
                 
        case 5

            lu=[-10*ones(1,n);10*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];    
                    
        case 6

            lu=[-100*ones(1,n);100*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
               
        case 7

            lu=[-100*ones(1,n);100*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];     
               
        case 8

            lu=[-1.28*ones(1,n);1.28*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
            
                   
        case 9

            lu=[-1.28*ones(1,n);1.28*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
                   
        case 10

            lu=[-5*ones(1,n);10*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
              
        case 11

            lu=[-5.12*ones(1,n);5.12*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];      
            
                    
        case 12

            lu=[-5.12*ones(1,n);5.12*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = []; 
           
        case 13

            lu=[-600*ones(1,n);600*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
     
        case 14

            lu=[-500*ones(1,n);500*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
                    
        case 15

            lu=[-32*ones(1,n);32*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
               
        case 16

            lu=[-50*ones(1,n);50*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
                  
        case 17

            lu=[-50*ones(1,n);50*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = []; 
               
        case 18

            lu=[-10*ones(1,n);10*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = []; 
            
         case 19

            lu=[-10*ones(1,n);10*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];    
                     
        case 20

            lu=[-0.5*ones(1,n);0.5*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = [];  
            
                  
        case 21

            lu=[-5*ones(1,n);5*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = []; 
                    
        case 22

            lu=[-0*ones(1,n);pi*ones(1,n)];
            o=[];A=[];M=[]; a = []; alpha = []; b = []; 

    end

    % Record the best results
    outcome = [];

    % Main body
    popsize = 50;

    time = 1;

    % The total number of runs
    totalTime = 10;
    
    SN=popsize;
    Xmax=lu(10,1);
    Xmin=lu(1,1);
     SR=0;
     Succ1=0;
     BFE=[];
     
    while time <= totalTime
  
        limit=ones(1,SN);
        Succ=0;
       
        % Initialize the main population
        Epop = repmat(lu(1, :), popsize, 1) + rand(popsize, n) .* (repmat(lu(2, :) - lu(1, :), popsize, 1));
      
        % Evaluate the objective function values
        for i=1:SN       
            Fit(i) = Truss_10bar_size(Epop(i,:), problem, o, A, M, a, alpha, b);
        end

        % Record the number of function evaluations (FES)
        FE = popsize;
               
        VVbest=[];
        DFE=[];
        sigma=0.1;
        Fm = 0.5;
       
       for  k=1:MCN
                 
            if FE>MaxFE
                break;
            end          
            if min(Fit)<Vot& Succ==0
                Succ1=Succ1+1;
                SR=SR+1;
                BFE(SR)=FE; 
                Succ=1;
            end            
            if min(Fit)==0             
                break;               
            end                    

            for i = 1 : SN   
                V=Epop(i,:);
                j=unidrnd(D);              
                k1=unidrnd(SN);
                [Fmin best]=min(Fit); 
                kk=unidrnd(SN);
                while kk==i
                    kk=unidrnd(SN);
                end
                V(j)=Epop(i,j)+1*(1-2*rand)*(Epop(i,j)-Epop(kk,j))+1.5*rand*(Epop(best,j)-Epop(i,j));
                if V(j)>Xmax|V(j)<Xmin
                    V(j)=Xmin+rand*(Xmax-Xmin);
                end
                Vfit=Truss_10bar_size(V,problem, o, A, M, a, alpha, b);
                FE = FE + 1;
                fitc(i)=Vfit;
                if Vfit<Fit(i)
                    Epop(i,:)=V;         
                    Fit(i)=Vfit;       
                    limit(i)=1;        
                else     
                    limit(i)=limit(i)+1;   %%%%%%%
                end       
            end


 
            NewFit=zeros(size(Fit));
            [Ms ds]=sort(Fit,'descend');   
            for i=1:SN          
                NewFit(ds(i))=i;   
            end
            Pfit=NewFit/sum(NewFit);
            copy=Roulette(Pfit,SN); 
           [Fmin best]=min(Fit); 
        
            for i=1:SN
                V=Epop(copy(i),:);
                j=unidrnd(D);                   
                k1=unidrnd(SN);
                [Fmin best]=min(Fit);
                kk=unidrnd(SN);
                    while kk==copy(i)
                        kk=unidrnd(SN);
                    end  
                    V(j)=Epop(copy(i),j)+1*(1-2*rand)*(Epop(copy(i),j)-Epop(kk,j))+1.5*rand*(Epop(best,j)-Epop(copy(i),j));
                           
                if V(j)>Xmax|V(j)<Xmin
                    V(j)=Xmin+rand*(Xmax-Xmin);
                end           
                Vfit=Truss_10bar_size(V,problem, o, A, M, a, alpha, b);
                FE=FE+1;
                fitc(i)=Vfit;
                if Vfit<Fit(copy(i))         
                    Epop(copy(i),:)=V;          
                    Fit(copy(i))=Vfit;  
                    limit(copy(i))=1;      
                else
                    limit(copy(i))=limit(copy(i))+1;   %%%%%%%
                end
            end

            for i=1:SN 
                if limit(i)>Lmax                      
                    for j=1:D                           
                        Epop(i,j)=Xmin+rand*(Xmax-Xmin);          
                    end  
                    Fit(i)=Truss_10bar_size(Epop(i,:),problem, o, A, M, a, alpha, b);                                
                    limit(i)=1;                              
                    FE=FE+1;                           
                    break;                      
                end
            end
                   
        DFE(k)=FE;
              
        if (k>2&VVbest(k-1)>min(Fit))|k==1
            VVbest(k)=min(Fit);
        else
             VVbest(k)=VVbest(k-1);
        end

       end
        outcome = [outcome VVbest(k-1)];
       time = time + 1;
         
    end

    problem
    Me=mean(outcome)
    SD=std(outcome)
end

function  TrussWeight=Truss_10bar_size_discrete(X)
%This solution illustrate the analyzing of truss structure
%Input
% this code for 2D 10brs truss structure (discrete design variables)
SECTION_List= [1.62, 1.8, 1.99, 2.13, 2.38, 2.62, 2.63, 2.88, 2.93, 3.09, 3.13, 3.38, 3.47, 3.35, 3.63, 3.84,3.87, 3.88, 4.18, 4.22, 4.49, 4.59, 4.8, 4.97, 5.12, 5.74, 7.22, 7.97, 11.5, 13.5, 13.9, 14.2, 15.5, 16.0, 16.9, 18.8, 19.9, 22.0, 22.9, 26.5, 30.0, 33.5]; % discrete section list    
A=[SECTION_List(X(1)), SECTION_List(X(2)), SECTION_List(X(3)), SECTION_List(X(4)), SECTION_List(X(5)), SECTION_List(X(6)), SECTION_List(X(7)), SECTION_List(X(8)), SECTION_List(X(9)), SECTION_List(X(10))]; % cross sectional areas of the truss

Dall =2;    % Allowable displacement 
Sall=25;    % Allowable stress 
E=10000;    % Modulus of elasticity
D=0.1;      % holds material density

N=[1 720 360;
   2 720 0;
   3 360 360;
   4 360 0;
   5 0 360;
   6 0 0];% x and y coordinates
M=[1 3 5 E A(1);
   2 1 3 E A(2);
   3 4 6 E A(3);
   4 2 4 E A(4);
   5 3 4 E A(5);
   6 1 2 E A(6);
   7 4 5 E A(7);
   8 3 6 E A(8);
   9 2 3 E A(9);
   10 1 4 E A(10)];
Re=[1 0 0 ;2 0 0 ;3 0 0 ;4 0 0 ;5 1 1 ;6 1 1 ]; 
nn =size(N,1);
ndof = 2*nn;
ne = size(M,1);
K = zeros(ndof,ndof);
U = zeros(ndof,1);
f = zeros(ndof,1);
F = zeros(ne,1);
stress = zeros(ne,1);
strain = zeros(ne,1);
f(8)=-100;
f(4)=-100;

fnod=[1 2 3 4 5 6 7 8];     %unconstrained dofs
for e=1:ne         %loops over all the element
    n1=M(e,2);     %starting node of element
    n2=M(e,3);     %end node of element
    x1=N(n1,2);  y1=N(n1,3);  %x and y coordinates for 1st node
    x2=N(n2,2);  y2=N(n2,3);  %x and y coordinates for 2nd node
    L(e)=sqrt((x2-x1)^2+(y2-y1)^2);    %element length
    C=(x2-x1)/L(e);
    S=(y2-y1)/L(e);
    C2=C*C;
    S2=S*S;
    CS=C*S;
    E= M(e,4); %Holds modolus of elasticiy of element
    A(e)=M(e,5);
    ke=((A(e)*E)/L(e)*[C2 CS -C2 -CS;   %stiffness matrix for element
                       CS S2 -CS -S2;
                      -C2 -CS C2 CS;
                      -CS -S2 CS S2]);
    s1=[M(e,2)*2-1 M(e,2)*2];
    s2=[M(e,3)*2-1 M(e,3)*2];  %location where ke is to scatter in the global stiffness matrix
    K([s1,s2],[s1,s2])= K([s1,s2],[s1,s2])+ke;    %adding ke to k
end
% solving for the nodal displacement,U
U(fnod)= K(fnod,fnod)\f(fnod);
% solving strain, stress and force for each element
for e=1:ne      
    n1=M(e,2);     
    n2=M(e,3);     
    x1=N(n1,2);  y1=N(n1,3);  
    x2=N(n2,2);  y2=N(n2,3);
    s1=[M(e,2)*2-1 M(e,2)*2];
    s2=[M(e,3)*2-1 M(e,3)*2];
    L(e)=sqrt((x2-x1)^2+(y2-y1)^2);    
    C=(x2-x1)/L(e);
    S=(y2-y1)/L(e);
    d=[C S 0 0;0 0 C S]*U([s1,s2]);  %displacement of one node
    strain(e)=(d(2)-d(1))/L(e);   %compute strain for each element, strain=(d2-d1)/应变
    stress(e)=E*strain(e);   %compute stresse for each element, stress=strain*modulus of elesticity for each element应力
   
    F(e)=A(e)*stress(e);   %compute axial force for each element, force=stress*cross section area for each element
    W(e)=D*A(e)*L(e);
end
net_weight=sum(W);

% Penalty function for dealing the constraints

penalty_constant=1;
        Svio=zeros(1,ne);
        Dvio=zeros(1,ndof);
        c1=size(Svio); 
        c2=size(Dvio);
           
for e=1:ne
        Svio(e)=(abs(stress(e))/Sall)-1;
        if Svio(e)<=0
          c1(e)=0;
        else c1(e)=Svio(e);
            
        end
end

    Sviolation=sum(c1);

for i=1:ndof
        Dvio(i)=(abs(U(i))/Dall)-1;
        if Dvio(i)<=0
            c2(i)=0;
        else c2(i)=Dvio(i);

        end
end
        
        Dviolation=sum(c2);
        violation=Sviolation+Dviolation;
        TrussWeight=net_weight*(1+penalty_constant*violation); %Cost function with penalty     
       
end

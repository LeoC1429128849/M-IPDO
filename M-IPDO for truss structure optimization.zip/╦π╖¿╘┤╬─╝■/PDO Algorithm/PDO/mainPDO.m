%_________________________________________________________________________
% Prairie Dogs Optimization source code demo version 
% Developed in MATLAB R2020b    
%  
% paper:
% Absalom E. Ezugwu, Jeffrey O. Agushaka, Laith Abualigah, Seyedali Mirjalili, Amir H Gandomi
% Prairie Dogs Optimization: A Nature-inspired Metaheuristic
%  
%  
% E-mails: EzugwuA@ukzn.ac.za                 Absalom E. Ezugwu
%          218088307@stu.ukzn.ac.za            Jeffrey O. Agushaka 
%           
%_________________________________________________________________________



clear all 
clc

PD_no=100;  %Number of prairie dogs
% CT_no=30;   %Number of coterie
F_name='F2';     %Name of the test function
Max_iter=1000;           %Maximum number of iterations

    
[LB,UB,Dim,F_obj]=Get_F(F_name); %Get details of the benchmark functions
[Best_PD,PDBest_P,PDConv]=PDO1(PD_no,Max_iter,LB,UB,Dim,F_obj); % Call PDO



figure('Position',[454   445   694   297]);
subplot(1,2,1);
func_plot(F_name);     % Function plot
title('Parameter space')
xlabel('x_1');
ylabel('x_2');
zlabel([F_name,'( x_1 , x_2 )'])
subplot(1,2,2);       % Convergence plot
plot(PDConv,'LineWidth',3)
xlabel('Iteration#');
ylabel('Best fitness so far');
legend('PDO');



display(['The best-obtained solution by PDO is : ', num2str(PDBest_P)]);  
display(['The best optimal value of the objective funciton found by PDO is : ', num2str(Best_PD)]);  

function [Best_PD,PDBest_P,PDConv,BPD_no]=PDO1(N,T,LB,UB,Dim,dDim,F_obj)      %N种群数量 T迭代次数
PDBest_P=zeros(1,Dim);           % best positions   %与当前最优所对应的位置
Best_PD=inf;                     %% global best fitness全局最优（函数最小值）
X=zeros(N,Dim);                  %Initialize the positions of solution随机初始位置
Xnew=zeros(N,Dim);
PDConv=zeros(1,T);               % Convergance array 记录收敛曲线
M=Dim;                            %set number of coteries
BPD_no=zeros(T,1);

%初始化
for i=1:N
    for j=1:Dim
        if j<=dDim %前面的为离散的截面变量
            X(i,j)=round(LB(j)+rand*(UB(j)-LB(j)));%四舍五入取整 截面积取值编号
        else
            X(i,j)=LB(j)+rand*(UB(j)-LB(j));
        end
    end
end

t=1;                         % starting iteration
delta=0.005;                   % account for individual PD difference   'delta'
% eps(MATLAB自带常数)        %food source quality
epsPD=0.1;                  % food source alarm     'rho'

OBest=zeros(1,size(X,1));     % old fitness values 个体最优（用于首尾）
CBest=zeros(1,size(X,1));     % new fitness values 本代值（临时容器用于迭代过程中）
%计算初始位置时的函数值
for i=1:size(X,1)
    OBest(1,i)=F_obj(X(i,:));
    if OBest(1,i)<Best_PD %初始化阶段的最优，即第一代迭代的旧全局最优
        Best_PD=OBest(1,i);
        PDBest_P=X(i,:); %与当前最优所对应的位置
    end
end

% 迭代开始 main loop
while t<T+1

    if mod(t,2)==0 %随代数在1和-1间变化
        mu=-1;
    else
        mu=1;
    end

    DS=1.5*(1-t/T)^(2*t/T)*mu;  % Digging strength
    PE=1.5*(1-t/T)^(2*t/T);  % Predator effect
    RL=levym(N,Dim,1.5);     % Levy random number vector
    TPD=repmat(PDBest_P,N,1); %Top PD
    for i=1:N
        for j=1:M %该个体寻找下一个目标
            cpd=((TPD(i,j)-rand*X(i,j)))/((TPD(i,j))+eps);
            P=(X(i,j)-mean(X(:,j)))/(TPD(i,j)*(UB(1,j)-LB(1,j))+delta);
            eCB=PDBest_P(1,j)*delta+P;
            % P=delta+(X(i,j)-mean(X(:,j)))/(TPD(i,j)*(UB(1,j)-LB(1,j))+delta);
            % eCB=PDBest_P(1,j)*P;
            if j<=15 %截面积序号变量
                if (t<T/4) %阶段1
                    Xnew(i,j)=round(PDBest_P(1,j)-eCB*epsPD-cpd*RL(i,j));
                elseif (t<2*T/4 && t>=T/4) %阶段2
                    Xnew(i,j)=round(PDBest_P(1,j)*X(randi([1 N]),j)*DS*RL(i,j));
                elseif (t<3*T/4 && t>=2*T/4) %阶段3
                    Xnew(i,j)=round(PDBest_P(1,j)-eCB*eps-cpd*rand);
                else %阶段4
                    Xnew(i,j)=round(PDBest_P(1,j)*PE*rand);
                end
            else %节点坐标位置变量
                if (t<T/4) %阶段1
                    Xnew(i,j)=PDBest_P(1,j)-eCB.*epsPD-cpd.*RL(i,j);
                elseif (t<2*T/4 && t>=T/4) %阶段2
                    Xnew(i,j)=PDBest_P(1,j)*X(randi([1 N]),j)*DS*RL(i,j);
                elseif (t<3*T/4 && t>=2*T/4) %阶段3
                    Xnew(i,j)=PDBest_P(1,j)-eCB*eps-cpd*rand;
                else %阶段4
                    Xnew(i,j)=PDBest_P(1,j)*PE*rand;
                end
            end
        end

        %将落在边界外的个体拉回边界
        Xnew(i,Xnew(i,:)>UB)=UB(1,Xnew(i,:)>UB);
        Xnew(i,Xnew(i,:)<LB)=LB(1,Xnew(i,:)<LB);

        CBest(1,i)=F_obj(Xnew(i,:));%CBest存储这一轮

        if CBest(1,i)<OBest(1,i)%判断个体是否需要更新位置,更新个体最优
            X(i,:)=Xnew(i,:);
            OBest(1,i)=CBest(1,i);
        end
        if OBest(1,i)<Best_PD%更新这一轮之内的全局最优
            Best_PD=OBest(1,i);
            PDBest_P=X(i,:);
        end
    end %end of for i

    PDConv(t)=Best_PD;  %Update the convergence curve记下这一代的全局最优记录收敛情况
    if mod(t,50)==0  %每五十代输出一次目前的最优
        display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(Best_PD)]);
    end
    t=t+1;
end %end for loop
end%end for function
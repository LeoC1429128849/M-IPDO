clear 
clc
tic
%%PDO参数设置
PD_no=32;      %Number of prairie dogs种群数量
Max_iter=1000; %Maximum number of iterations最大迭代次数
runNum=20;      %重复运行次数
F_name='F18';  %选择目标函数
[LB,UB,Dim,dDim,F_obj]=Get_F(F_name); %获取目标函数对应参数
A=zeros(runNum,Max_iter); % 记录每run收敛过程
PDBest_PerRun=zeros(runNum,Dim); %记录每一run的最佳设计方案
for run=1:runNum
    disp(['run #' num2str(run)]);
    [Best_PD,PDBest_P,PDConv]=DBO(PD_no,Max_iter,LB,UB,Dim,dDim,F_obj); % Call PDO调用 前面的是返还的值
    A(run,:)=PDConv;
    PDBest_PerRun(run,:)=PDBest_P;
    display(['The best-obtained solution by PDO is : ', num2str(PDBest_P)]);  %最优设计函数变量
    display(['The best optimal value of the objective funciton found by PDO is : ', num2str(Best_PD)]);  %最优目标函数值
end
CoTime=toc;
%"result" 结构体中是关于结果的数据
%结果存储
[result.best,result.bestindex]=min(A(:,end));  %最好结果 和对应的run
[result.worst,result.worstindex]=max(A(:,end));%最差结果 和对应的run
result.PDBest_P_AllRun=PDBest_PerRun(result.bestindex,:); %20run的最佳设计方案
[~, result.stress, result.CVP]=F_obj(result.PDBest_P_AllRun);  %最优解下的应力状态
result.mean=mean(A(:,end));
result.std=std(A(:,end));
result.ResultPerRun=A(:,end); %20次运行每次的结果
AVE=mean(A,1);  %平均收敛曲线
disp('*********************** all runs are end *************************')
display(['the best solution:',num2str(result.best),'  the best run: ',num2str(result.bestindex)])
display(['the worst solution:',num2str(result.worst),'  the worst run: ',num2str(result.worstindex)])
display(['the mean of solution:',num2str(result.mean),'  the std of solution: ',num2str(result.std)])

%%画图部分
figure()
plot(A(result.bestindex,:),'color','#4bb6f4','LineWidth',2,'LineStyle','--');
hold on;
plot(AVE,'color','black','LineWidth',2);
hold on;
plot(A(result.worstindex,:),'color','#ef4b4c','LineWidth',2,'LineStyle','--');
xlabel('Number of iterations');  
ylabel('Best fitness so far');
legend('PDO best ','PDO average','PDO worst');
title('Convergence curve')
grid on;


% %桁架形状
truss_plot(result.PDBest_P_AllRun,F_name) %F_name 为桁架名（F15,F18,F25）

% 应力状态
figure('Position',[100, 100, 560, 420])
plot(1:18,result.stress,'o','LineWidth',1.5)
hold on 
plot(1:18,20*ones(18,1),1:18,-20*ones(18,1),'LineWidth',1.5,'Color','r')
xlim([0 18.5])
xticks(0:1:18)
ylim([-30 30])
set(gca,fontname='Times new roman',fontsize=11)
xlabel('Number of members','FontWeight','bold',fontsize=12);
ylabel('Stress (Ksi)','FontWeight','bold',fontsize=12);
legend('Element stress','Allowable stress','Orientation','horizontal')
set(gcf, 'Units', 'centimeters');  %设置输出图片单位为厘米
set(gcf, 'Position', [0, 0, 9, 7.75]);    %设置输出图片大小（厘米）














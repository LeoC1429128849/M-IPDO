x = [0,0];
y = [0,0];
beta =2;
sigma_u = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
sigma_v = 1;
figure()
for i=1:200
    u = normrnd(0,sigma_u);
    v = normrnd(0,sigma_v);
    s = u/(abs(v))^(1/beta);
    x(:,1) = x(:,2);
    x(:,2) = x(:,1)+1*s;
    
    u = normrnd(0,sigma_u);
    v = normrnd(0,sigma_v);
    s = u/(abs(v))^(1/beta);
    y(:,1) = y(:,2);
    y(:,2) = y(:,1)+1*s;
    
    plot(x,y,LineWidth=1.1);
    hold on;
end
set(gca,fontname='Times New Roman',fontsize=11);

xlabel('x','FontWeight','bold','FontSize',12);ylabel('y','FontWeight','bold','FontSize',12)
legend('Trace')
title('{\it\beta}{ = 1.5}',FontSize=14,FontWeight='bold')
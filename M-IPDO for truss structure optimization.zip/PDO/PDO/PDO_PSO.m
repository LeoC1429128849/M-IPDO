clear all
clc
%%PDO
PD_no=1000;  %Number of prairie dogs种群数量
F_name='F24';     %Name of the test function测试函数
Max_iter=1000;           %Maximum number of iterations最大迭代次数
[LB,UB,Dim,F_obj]=Get_F(F_name); %Get details of the benchmark functions获取目标函数对应参数
[Best_PD,PDBest_P,PDConv]=PDO1(PD_no,Max_iter,LB,UB,Dim,F_obj); % Call PDO调用 前面的是返还的值
display(['The best-obtained solution by PDO is : ', num2str(PDBest_P)]);  %最优设计函数变量
display(['The best optimal value of the objective funciton found by PDO is : ', num2str(Best_PD)]);  %最优目标函数值

%%%%%%%%%%%%/ section of PSO /%%%%%%%%%%%%%%%% 
%初始化参数
%粒子群算法的两个参数
c1=1.49445;
c2=c1;
%进化次数
maxgen=1000;
%种群规模
sizepop=1000;
%更新速度
vmax=1;
vmin=-1;
%种群
popmax=[2 10 10 2];
popmin=[0.1 0.1 0.1 0.1];
mubiao=@F24;
par_num=4;
pop=zeros(sizepop,par_num);
V=zeros(sizepop,par_num);
fitness=ones(1,sizepop)*1000;
%产生初始粒子及速度
for i = 1 :sizepop
    for j=1:par_num
    %随机产生一个种群
    %初始种群
    pop(i,j)=rand*(popmax(1,j)-popmin(1,j))+popmin(1,j);
    %初始速度
    V(i,j)=1.*rands(1,1);
    %目标函数
    end
    %*判断是否满足约束条件*%（后期更换为罚函数）
    if judge(pop(i,:))==1
    fitness(1,i)=mubiao(pop(i,:));
    end
end
%找到最好的适应度
[bestfitness,bestindex]=min(fitness);
%全局最佳
zbest=pop(bestindex,:);
%个体最佳
gbest=pop;
%个体最佳适应度
fitnessgbest=fitness;
%全局最佳适应度
fitnesszbest=bestfitness;
%寻找最优
for i=1:maxgen
    for j=1:sizepop
        %速度更新
        V(j,:)=V(j,:)+c1*rand*(gbest(j,:)-pop(j,:))+c2*rand*(zbest-pop(j,:));
        V(j,V(j,:)>vmax)=vmax;
        V(j,V(j,:)<vmin)=vmin;
        %种群更新
        pop(j,:)=pop(j,:)+0.5* V(j,:);
        %检查是否超出上下界
        pop(j,pop(j,:)>popmax)=popmax(1,pop(j,:)>popmax);
        pop(j,pop(j,:)<popmin)=popmin(1,pop(j,:)<popmin);
        %自适应变异
        if rand>0.8
            k=ceil(par_num*rand);
            pop(j,k)=rand;
        end
        %适应度
        if judge(pop(j,:))==1
            fitness(j)=mubiao(pop(j,:));
        end
        %个体最优更新
        if fitness(j)<fitnessgbest(j)
            gbest(j,:)=pop(j,:);
            fitnessgbest(j)=fitness(j);
        end
        %群体最优更新
        if fitness(j)<fitnesszbest
            zbest=pop(j,:);
            fitnesszbest=fitness(j);
        end
    end
    jieguo(i)=fitnesszbest;
    if mod(i,50)==0
        display(['At iteration ', num2str(i), ' the best solution fitness is ', num2str(fitnesszbest)])
    end
end
display(['The best-obtained solution by PSO is : ', num2str(zbest)]);  %最优设计函数变量
display(['The best optimal value of the objective funciton found by PSO is : ', num2str(fitnesszbest)]);  %最优目标函数值

%%画出收敛曲线
plot(PDConv,'color','#4bb6f4','LineWidth',1);
hold on;
plot(jieguo,'color','#ef4b4c','LineWidth',1);
xlabel('Iteration#');
ylabel('Best fitness so far');
legend('PDO','PSO');
title('Convergence curve')
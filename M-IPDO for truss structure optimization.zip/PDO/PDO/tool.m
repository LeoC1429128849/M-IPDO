%查看种群多样性
figure()
histogram(X(:,1))
title('X(1) in 32 indibiduals')
xlable('')
ylabel('value of X(1)')

%
X=zeros(1);

[~, result.stress, result.CVP]=F_obj(X);  %最优解下的应力状态
truss_plot(X,F_name) %F_name 为桁架名（F15,F18,F25）


%
plot(1:10,A,1:10,B)
hold on
plot(1:10,ones(1,10))
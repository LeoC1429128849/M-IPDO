% 将面积转为截面号
% 计算应力情况 
%X是设计变量


%% case of 15 bars
X=0;
SECTION_List1= [0.111, 0.141, 0.174, 0.220, 0.270, 0.287, 0.347, 0.440, 0.539, 0.954, 1.081, 1.174, 1.333, 1.488, 1.764, 2.142, 2.697, 2.800, 3.131, 3.565, 3.813, 4.805, 5.952, 6.572, 7.192, 8.525, 9.300, 10.850, 13.330, 14.290, 17.170, 19.180]; % discrete section list    32 choices
for i=1:15
    X(i)=find(SECTION_List1==X(i));
end
F_name='F15';  %选择目标函数
[LB,UB,Dim,dDim,F_obj] = Get_F(F_name);
%计算应力情况
[TrussWeight,stress,violation]=F_obj(X);



%% case of 18 bars
SECTION_List1= 2:0.25:21.75;
result.PDBest_P_AllRun(1:4)=SECTION_List1([41	65	15	11]);
